import Link from 'next/link'
import { createAdminClient } from '@/lib/supabase/admin'
import PublicHeader from '@/components/public/header'
import PublicFooter from '@/components/public/footer'
import SafariImage from '@/components/public/safari-image'
import WhatsAppButton from '@/components/public/whatsapp-button'
import SectionReveal from '@/components/public/section-reveal'
import { getServerLocale } from '@/lib/i18n'
import { STOCK_HERO_IMAGE } from '@/lib/stock-images'
import { MapPin, Clock, ArrowRight } from 'lucide-react'

const OLIVE = '#7A9A4A'
const OLIVE_DK = '#3D5229'
const BUSH = '#20271A'
const STONE = '#6E6A59'
const SAND = '#EAE3D2'
const MURRAM = '#B0492B'
const GOLD = '#C9A24B'

export const dynamic = 'force-dynamic'

export default async function ToursPage({
  searchParams,
}: {
  searchParams: Promise<{ lang?: string }>
}) {
  const sp = await searchParams
  const locale = await getServerLocale(sp)
  const isAr = locale === 'ar'
  const dir = isAr ? 'rtl' : 'ltr'

  const admin = createAdminClient()

  const { data: tours } = await admin
    .from('tours')
    .select('id, title_en, title_ar, subtitle_en, overview_en, type, duration_days, duration_nights, countries_visited, status, hero_image_url, gallery_urls')
    .eq('status', 'active')
    .order('title_en')

  const t = isAr ? {
    title: 'جولات السفاري لدينا',
    subtitle: 'استكشف مجموعتنا المختارة من تجارب السفاري التي لا تُنسى في شرق أفريقيا.',
    days: 'أيام',
    requestQuote: 'طلب عرض سعر',
    none: 'لا توجد جولات متاحة بعد. تحقق قريباً!',
    ctaTitle: 'لم تجد الجورة المثالية؟',
    ctaText: 'أخبرنا بتفضيلاتك وسننشئ رحلة سفاري مخصصة لك.',
    ctaButton: 'أنشئ جولة مخصصة',
  } : {
    title: 'Our Safari Tours',
    subtitle: 'Explore our curated collection of unforgettable East African safari experiences. Each tour is designed to showcase incredible wildlife and landscapes.',
    days: 'days',
    requestQuote: 'View Details',
    none: 'No tours available yet. Check back soon!',
    ctaTitle: "Can't Find the Perfect Tour?",
    ctaText: "Let us know your preferences and we'll create a custom safari just for you.",
    ctaButton: 'Create a Custom Tour',
  }

  return (
    <div dir={dir}>
      <PublicHeader />
      <main>
        {/* Page Hero */}
        <section
          style={{
            minHeight: '40vh',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            position: 'relative',
            overflow: 'hidden',
            background: BUSH,
          }}
        >
          <div style={{
            position: 'absolute',
            inset: 0,
            backgroundImage: `linear-gradient(rgba(32, 39, 26, 0.65), rgba(32, 39, 26, 0.75)), url(${STOCK_HERO_IMAGE})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }} />
          <div style={{
            position: 'relative',
            textAlign: 'center',
            padding: '120px var(--container-px) 60px',
            maxWidth: 720,
          }}>
            <h1 className="text-display-xl" style={{ color: '#FFFFFF', margin: '0 0 16px' }}>
              {t.title}
            </h1>
            <p className="text-body-l" style={{ color: 'rgba(255, 255, 255, 0.8)', margin: 0 }}>
              {t.subtitle}
            </p>
          </div>
        </section>

        {/* Tours Grid */}
        <section style={{ background: SAND, padding: 'var(--section-py) var(--container-px)' }}>
          <div style={{ maxWidth: 'var(--content-max)', margin: '0 auto' }}>
            {tours && tours.length > 0 ? (
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill, minmax(min(100%, 340px), 1fr))',
                gap: 'var(--card-gap)',
              }}>
                {tours.map((tour: any, index: number) => {
                  const title = isAr ? (tour.title_ar || tour.title_en) : tour.title_en
                  const desc = tour.overview_en || tour.subtitle_en || ''
                  const isBike = tour.type === 'bike'
                  const accentColor = isBike ? MURRAM : GOLD
                  const badgeLabel = isBike
                    ? (isAr ? 'جولة دراجات' : 'BIKE TOUR')
                    : (isAr ? 'سفاري خاص' : 'PRIVATE SAFARI')

                  return (
                    <SectionReveal key={tour.id} delay={index * 0.08}>
                      <Link
                        href={`/tours/${tour.id}?lang=${locale}`}
                        style={{
                          display: 'block',
                          textDecoration: 'none',
                          background: '#FFFFFF',
                          borderRadius: 'var(--radius-l)',
                          overflow: 'hidden',
                          boxShadow: 'var(--shadow-m)',
                          transition: 'var(--trans-std)',
                          height: '100%',
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.transform = 'translateY(-4px)'
                          e.currentTarget.style.boxShadow = 'var(--shadow-hover)'
                          const img = e.currentTarget.querySelector('.tour-card-img') as HTMLElement
                          if (img) img.style.transform = 'scale(1.04)'
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.transform = 'translateY(0)'
                          e.currentTarget.style.boxShadow = 'var(--shadow-m)'
                          const img = e.currentTarget.querySelector('.tour-card-img') as HTMLElement
                          if (img) img.style.transform = 'scale(1)'
                        }}
                      >
                        {/* Image area */}
                        <div style={{
                          position: 'relative',
                          height: 260,
                          overflow: 'hidden',
                        }}>
                          <SafariImage
                            src={tour.hero_image_url || tour.gallery_urls?.[0]}
                            seed={tour.id}
                            alt={title}
                            className="tour-card-img w-full h-full"
                            sizes="(max-width: 768px) 100vw, 33vw"
                          />
                          {/* Badge */}
                          <div
                            className="text-caption"
                            style={{
                              position: 'absolute',
                              top: 16,
                              left: 16,
                              background: accentColor,
                              color: '#FFFFFF',
                              padding: '4px 12px',
                              borderRadius: 'var(--radius-s)',
                            }}
                          >
                            {badgeLabel}
                          </div>
                        </div>

                        {/* Content area */}
                        <div style={{ padding: 'var(--card-pad)' }}>
                          <h3 className="text-display-m" style={{ color: BUSH, margin: '0 0 8px' }}>
                            {title}
                          </h3>

                          {tour.countries_visited && (
                            <div className="text-body-s flex items-center gap-1.5" style={{ color: STONE, marginBottom: 6 }}>
                              <MapPin size={13} />
                              {tour.countries_visited}
                            </div>
                          )}

                          {tour.duration_days && (
                            <div className="text-body-s flex items-center gap-1.5" style={{ color: BUSH, marginBottom: 12 }}>
                              <Clock size={13} />
                              <span style={{ fontWeight: 500 }}>
                                {tour.duration_days} {t.days}
                                {tour.duration_nights ? ` · ${tour.duration_nights} nights` : ''}
                              </span>
                            </div>
                          )}

                          {desc && (
                            <p className="text-body-s line-clamp-3" style={{ color: STONE, margin: '0 0 20px' }}>
                              {desc}
                            </p>
                          )}

                          <div className="flex items-center justify-between">
                            <span className="text-body" style={{ color: BUSH, fontWeight: 600 }}>
                              {isAr ? 'من $X,XXX' : 'From $X,XXX'}
                            </span>
                            <span
                              className="text-body-s flex items-center gap-1"
                              style={{ color: OLIVE, fontWeight: 500 }}
                            >
                              {t.requestQuote}
                              <ArrowRight size={14} />
                            </span>
                          </div>
                        </div>
                      </Link>
                    </SectionReveal>
                  )
                })}
              </div>
            ) : (
              <div className="text-center py-16">
                <p className="text-body-l" style={{ color: STONE }}>{t.none}</p>
              </div>
            )}
          </div>
        </section>

        {/* Custom Tour CTA */}
        <section style={{ background: '#FFFFFF', padding: 'var(--section-py) var(--container-px)' }}>
          <div style={{ maxWidth: 640, margin: '0 auto', textAlign: 'center' }}>
            <SectionReveal>
              <h2 className="text-display-l" style={{ color: BUSH, margin: '0 0 16px' }}>
                {t.ctaTitle}
              </h2>
              <p className="text-body-l" style={{ color: STONE, margin: '0 0 32px' }}>
                {t.ctaText}
              </p>
              <Link
                href={`/quote-request?lang=${locale}`}
                className="text-button"
                style={{
                  background: OLIVE,
                  color: '#FFFFFF',
                  padding: '14px 32px',
                  borderRadius: 'var(--radius-s)',
                  textDecoration: 'none',
                  display: 'inline-block',
                  transition: 'var(--trans-fast)',
                }}
              >
                {t.ctaButton}
              </Link>
            </SectionReveal>
          </div>
        </section>
      </main>
      <PublicFooter />
      <WhatsAppButton lang={locale} />
    </div>
  )
}
