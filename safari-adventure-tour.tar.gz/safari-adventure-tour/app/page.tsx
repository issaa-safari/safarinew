import { Suspense } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { createClient } from '@/lib/supabase/server'
import PublicHeader from '@/components/public/header'
import PublicFooter from '@/components/public/footer'
import WhatsAppButton from '@/components/public/whatsapp-button'
import FeaturedDepartures from '@/components/public/featured-departures'
import Testimonials from '@/components/public/testimonials'
import HomeHero from '@/components/public/home-hero'
import ChooseYourTrail from '@/components/public/choose-your-trail'
import SectionReveal from '@/components/public/section-reveal'
import { getServerLocale } from '@/lib/i18n'
import { whatsappLink } from '@/lib/site'
import SafariImage from '@/components/public/safari-image'
import { Check, MapPin, Calendar, MessageCircle } from 'lucide-react'

const BUSH = '#20271A'
const OLIVE = '#7A9A4A'
const STONE = '#6E6A59'
const SAND = '#EAE3D2'

export const dynamic = 'force-dynamic'

export default async function HomePage({
  searchParams,
}: {
  searchParams: Promise<{ lang?: string }>
}) {
  const sp = await searchParams
  const locale = await getServerLocale(sp)
  const isAr = locale === 'ar'
  const dir = isAr ? 'rtl' : 'ltr'

  const supabase = await createClient()

  // Fetch one active tour per type to power the trail cards and hero
  const { data: tours } = await supabase
    .from('tours')
    .select('id, type, hero_image_url, gallery_urls')
    .eq('status', 'active')
    .in('type', ['bike', 'private'])
    .limit(10)

  const bikeTour = (tours ?? []).find(t => t.type === 'bike') ?? null
  const privateTour = (tours ?? []).find(t => t.type === 'private') ?? null

  // Hero image: prefer the bike tour's hero (most dramatic), fall back to private
  const heroTour = bikeTour ?? privateTour
  const heroImageUrl: string | null =
    (heroTour?.hero_image_url as string | null) ??
    ((heroTour?.gallery_urls as string[] | null)?.[0] ?? null)

  const bikeImageUrl: string | null =
    (bikeTour?.hero_image_url as string | null) ??
    ((bikeTour?.gallery_urls as string[] | null)?.[0] ?? null)
  const privateImageUrl: string | null =
    (privateTour?.hero_image_url as string | null) ??
    ((privateTour?.gallery_urls as string[] | null)?.[0] ?? null)

  const waHref = whatsappLink(
    isAr ? 'مرحباً، أود الاستفسار عن جولة' : "Hi, I'd like to enquire about a tour"
  )

  const t = isAr ? {
    featuredHeading: 'المواعيد القادمة',
    credibility1: 'مقرنا نيروبي، كينيا',
    credibility2: 'تأسسنا عام 2009',
    credibility3: 'نتحدث الإنجليزية والعربية والسواحيلية',
    whyEyebrow: 'لماذا الحجز المباشر',
    whyTitle: 'تجاوز الوسيط',
    whyBody1: 'عندما تحجز مباشرة معنا، كل دولار يذهب لصياغة سفاريك المثالي — وليس رسوم العمولة.',
    whyBody2: 'ستتحدث مباشرة مع فريقنا في نيروبي الذي يعرف كل درب، كل مخيم، وكل نقطة إطلالة سرية.',
    benefit1: 'أفضل ضمان للسعر',
    benefit2: 'تغييرات مجانية في خط السير',
    benefit3: 'دعم على مدار الساعة',
    whyCta: 'ابدأ رحلتك',
    testimonialsLabel: 'ماذا يقول مسافرونا',
    ctaHeading: 'هل أنت مستعد لتخطيط رحلتك؟',
    ctaSub: 'تواصل معنا لتحصل على عرض مخصص، أو ابدأ محادثة على واتساب.',
    ctaQuote: 'طلب عرض سعر',
    ctaWhatsapp: 'تحدث معنا على واتساب',
  } : {
    featuredHeading: 'Upcoming Departures',
    credibility1: 'Based in Nairobi, Kenya',
    credibility2: 'Operating since 2009',
    credibility3: 'English · Arabic · Swahili',
    whyEyebrow: 'WHY BOOK DIRECT',
    whyTitle: 'Skip the Middleman',
    whyBody1: "When you book directly with us, every dollar goes toward crafting your perfect safari — not commission fees.",
    whyBody2: "You'll speak directly with our team in Nairobi who know every trail, every camp, and every secret viewpoint.",
    benefit1: 'Best price guarantee',
    benefit2: 'Free itinerary changes',
    benefit3: '24/7 in-country support',
    whyCta: 'Start Your Journey',
    testimonialsLabel: 'What Our Guests Say',
    ctaHeading: 'Ready to Plan Your Trip?',
    ctaSub: 'Get in touch for a personalised quote, or start a conversation on WhatsApp.',
    ctaQuote: 'Request a Quote',
    ctaWhatsapp: 'Chat on WhatsApp',
  }

  return (
    <div dir={dir}>
      <Suspense>
        <PublicHeader />
      </Suspense>

      <main>
        {/* 1. Hero */}
        <HomeHero
          heroImageUrl={heroImageUrl}
          heroTourId={heroTour?.id ?? null}
          isAr={isAr}
          locale={locale}
        />

        {/* 2. Choose Your Trail */}
        <ChooseYourTrail
          bikeCard={{ type: 'bike', imageUrl: bikeImageUrl, tourId: bikeTour?.id ?? null }}
          privateCard={{ type: 'private', imageUrl: privateImageUrl, tourId: privateTour?.id ?? null }}
          isAr={isAr}
          locale={locale}
        />

        {/* 3. Featured Departures */}
        <div style={{ background: SAND }}>
          <div style={{ padding: 'var(--section-py) var(--container-px)' }}>
            <div style={{ maxWidth: 'var(--content-max)', margin: '0 auto' }}>
              <SectionReveal>
                <div style={{ marginBottom: 48, display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', flexWrap: 'wrap', gap: 16 }}>
                  <div>
                    <span className="text-caption" style={{ color: OLIVE, display: 'block', marginBottom: 8 }}>
                      {isAr ? 'المواعيد القادمة' : 'UPCOMING DEPARTURES'}
                    </span>
                    <h2 className="text-display-l" style={{ color: BUSH, margin: 0 }}>
                      {t.featuredHeading}
                    </h2>
                  </div>
                  <Link
                    href={`/departures?lang=${locale}`}
                    className="text-body-s link-underline"
                    style={{ color: OLIVE, textDecoration: 'none' }}
                  >
                    {isAr ? 'عرض الكل →' : 'View All →'}
                  </Link>
                </div>
              </SectionReveal>
              <FeaturedDepartures lang={locale} />
            </div>
          </div>
        </div>

        {/* 4. Credibility bar */}
        <SectionReveal>
          <section style={{ background: BUSH, padding: '32px var(--container-px)' }}>
            <div style={{
              maxWidth: 'var(--content-max)',
              margin: '0 auto',
              display: 'flex',
              flexWrap: 'wrap',
              justifyContent: 'center',
              alignItems: 'center',
              gap: '8px 40px',
            }}>
              {[
                { icon: MapPin, text: t.credibility1 },
                { icon: Calendar, text: t.credibility2 },
                { icon: MessageCircle, text: t.credibility3 },
              ].map((item, i) => (
                <span key={i} className="text-caption" style={{
                  color: 'rgba(234, 227, 210, 0.8)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 10,
                }}>
                  {i > 0 && (
                    <span aria-hidden="true" style={{ color: 'rgba(234, 227, 210, 0.3)', fontSize: '1rem' }}>·</span>
                  )}
                  <item.icon size={14} style={{ color: OLIVE }} />
                  {item.text}
                </span>
              ))}
            </div>
          </section>
        </SectionReveal>

        {/* 5. Why Book Direct */}
        <section style={{ background: '#FFFFFF', padding: 'var(--section-py) var(--container-px)' }}>
          <div style={{
            maxWidth: 'var(--content-max)',
            margin: '0 auto',
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 440px), 1fr))',
            gap: 'var(--grid-gap)',
            alignItems: 'center',
          }}>
            <SectionReveal direction="left">
              <div>
                <span className="text-caption" style={{ color: OLIVE, display: 'block', marginBottom: 8 }}>
                  {t.whyEyebrow}
                </span>
                <h2 className="text-display-l" style={{ color: BUSH, margin: '0 0 24px' }}>
                  {t.whyTitle}
                </h2>
                <p className="text-body" style={{ color: STONE, margin: '0 0 16px', maxWidth: 480 }}>
                  {t.whyBody1}
                </p>
                <p className="text-body" style={{ color: STONE, margin: '0 0 24px', maxWidth: 480 }}>
                  {t.whyBody2}
                </p>
                <ul style={{ listStyle: 'none', padding: 0, margin: '0 0 32px' }}>
                  {[t.benefit1, t.benefit2, t.benefit3].map((benefit, i) => (
                    <li key={i} className="text-body" style={{
                      color: BUSH,
                      display: 'flex',
                      alignItems: 'center',
                      gap: 10,
                      marginBottom: 10,
                    }}>
                      <span style={{
                        width: 20,
                        height: 20,
                        borderRadius: '50%',
                        background: 'var(--olive-lt)',
                        display: 'inline-flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        flexShrink: 0,
                      }}>
                        <Check size={12} style={{ color: OLIVE }} />
                      </span>
                      {benefit}
                    </li>
                  ))}
                </ul>
                <Link
                  href={`/quote-request?lang=${locale}`}
                  className="text-button"
                  style={{
                    background: OLIVE,
                    color: '#FFFFFF',
                    padding: '14px 28px',
                    borderRadius: 'var(--radius-s)',
                    textDecoration: 'none',
                    display: 'inline-block',
                    transition: 'var(--trans-fast)',
                  }}
                >
                  {t.whyCta}
                </Link>
              </div>
            </SectionReveal>

            <SectionReveal direction="right">
              <div style={{ position: 'relative' }}>
                <div style={{
                  borderRadius: 'var(--radius-l)',
                  overflow: 'hidden',
                  boxShadow: 'var(--shadow-l)',
                  transform: 'rotate(-1.5deg)',
                }}>
                  <SafariImage
                    src={null}
                    seed="why-direct"
                    alt="Safari experience"
                    className="w-full"
                    sizes="(max-width: 768px) 100vw, 50vw"
                  />
                </div>
                <div style={{
                  position: 'absolute',
                  bottom: -20,
                  [isAr ? 'left' : 'right']: 20,
                  background: '#FFFFFF',
                  borderRadius: 'var(--radius-m)',
                  boxShadow: 'var(--shadow-m)',
                  padding: '20px 24px',
                  textAlign: 'center',
                }}>
                  <span className="text-display-m" style={{ color: BUSH, display: 'block' }}>15+</span>
                  <span className="text-body-s" style={{ color: STONE }}>
                    {isAr ? 'سنوات من الخبرة' : 'Years of expertise'}
                  </span>
                </div>
              </div>
            </SectionReveal>
          </div>
        </section>

        {/* 6. Testimonials */}
        <div style={{ background: SAND }}>
          <div style={{ padding: 'var(--section-py) var(--container-px)' }}>
            <div style={{ maxWidth: 'var(--content-max)', margin: '0 auto' }}>
              <SectionReveal>
                <div style={{ textAlign: 'center', marginBottom: 48 }}>
                  <span className="text-caption" style={{ color: OLIVE, display: 'block', marginBottom: 8 }}>
                    {isAr ? 'قصص المسافرين' : 'TRAVELLER STORIES'}
                  </span>
                  <h2 className="text-display-l" style={{ color: BUSH, margin: 0 }}>
                    {t.testimonialsLabel}
                  </h2>
                </div>
              </SectionReveal>
              <Testimonials lang={locale} />
            </div>
          </div>
        </div>

        {/* 7. Final CTA */}
        <section style={{
          background: BUSH,
          padding: 'var(--section-py-lg) var(--container-px)',
          position: 'relative',
          overflow: 'hidden',
        }}>
          {/* Subtle background texture */}
          <div style={{
            position: 'absolute',
            inset: 0,
            opacity: 0.08,
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }} />
          <div style={{ position: 'relative', maxWidth: 640, margin: '0 auto', textAlign: 'center' }}>
            <SectionReveal>
              <h2 className="text-display-l" style={{ color: '#FFFFFF', margin: '0 0 16px' }}>
                {t.ctaHeading}
              </h2>
              <p className="text-body-l" style={{ color: 'rgba(255, 255, 255, 0.75)', margin: '0 0 36px' }}>
                {t.ctaSub}
              </p>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 14, justifyContent: 'center' }}>
                <Link
                  href={`/quote-request?lang=${locale}`}
                  className="text-button"
                  style={{
                    background: OLIVE,
                    color: '#FFFFFF',
                    padding: '14px 32px',
                    borderRadius: 'var(--radius-s)',
                    textDecoration: 'none',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: 8,
                    transition: 'var(--trans-fast)',
                  }}
                >
                  {t.ctaQuote}
                </Link>
                <a
                  href={waHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-button"
                  style={{
                    background: 'rgba(255, 255, 255, 0.15)',
                    border: '1px solid rgba(255, 255, 255, 0.25)',
                    color: '#FFFFFF',
                    padding: '14px 32px',
                    borderRadius: 'var(--radius-s)',
                    textDecoration: 'none',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: 8,
                    transition: 'var(--trans-fast)',
                  }}
                >
                  {t.ctaWhatsapp}
                </a>
              </div>
            </SectionReveal>
          </div>
        </section>
      </main>

      <PublicFooter />
      <WhatsAppButton lang={locale} />
    </div>
  )
}
