'use client'

import { useRef } from 'react'
import { motion, useInView, useReducedMotion } from 'framer-motion'
import Link from 'next/link'
import SafariImage from '@/components/public/safari-image'
import { ArrowRight, ArrowLeft } from 'lucide-react'

const MURRAM = '#B0492B'
const GOLD = '#C9A24B'
const BUSH = '#20271A'
const SAND = '#EAE3D2'

const EASE = [0.22, 1, 0.36, 1] as const

interface TrailCard {
  type: 'bike' | 'private'
  imageUrl: string | null
  tourId: string | null
}

interface ChooseYourTrailProps {
  bikeCard: TrailCard
  privateCard: TrailCard
  isAr: boolean
  locale: string
}

function ForkSVG({ inView, reduced, isAr }: { inView: boolean; reduced: boolean | null; isAr: boolean }) {
  return (
    <svg
      viewBox="0 0 200 80"
      style={{ width: '100%', maxWidth: 360, display: 'block', margin: '0 auto' }}
      aria-hidden="true"
    >
      {/* Stem */}
      <motion.line
        x1="100" y1="0" x2="100" y2="36"
        stroke={SAND} strokeWidth="2" strokeLinecap="round"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: reduced ? 1 : (inView ? 1 : 0) }}
        transition={{ duration: 0.4, ease: EASE }}
      />
      {/* Left fork — bike / murram */}
      <motion.path
        d={isAr ? "M100,36 Q100,70 160,78" : "M100,36 Q100,70 40,78"}
        fill="none" stroke={MURRAM} strokeWidth="2.5" strokeLinecap="round"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: reduced ? 1 : (inView ? 1 : 0) }}
        transition={{ duration: 0.5, delay: 0.3, ease: EASE }}
      />
      {/* Right fork — private / gold */}
      <motion.path
        d={isAr ? "M100,36 Q100,70 40,78" : "M100,36 Q100,70 160,78"}
        fill="none" stroke={GOLD} strokeWidth="2.5" strokeLinecap="round"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: reduced ? 1 : (inView ? 1 : 0) }}
        transition={{ duration: 0.5, delay: 0.4, ease: EASE }}
      />
      {/* End dots */}
      <motion.circle
        cx={isAr ? 160 : 40} cy="78" r="5" fill={MURRAM}
        initial={{ scale: 0 }} animate={{ scale: reduced ? 1 : (inView ? 1 : 0) }}
        transition={{ duration: 0.25, delay: 0.75, ease: EASE }}
        style={{ transformOrigin: `${isAr ? 160 : 40}px 78px` }}
      />
      <motion.circle
        cx={isAr ? 40 : 160} cy="78" r="5" fill={GOLD}
        initial={{ scale: 0 }} animate={{ scale: reduced ? 1 : (inView ? 1 : 0) }}
        transition={{ duration: 0.25, delay: 0.8, ease: EASE }}
        style={{ transformOrigin: `${isAr ? 40 : 160}px 78px` }}
      />
    </svg>
  )
}

export default function ChooseYourTrail({ bikeCard, privateCard, isAr, locale }: ChooseYourTrailProps) {
  const reduced = useReducedMotion()
  const ref = useRef<HTMLDivElement>(null)
  const inView = useInView(ref, { once: true, margin: '-80px' })
  const dir = isAr ? 'rtl' : 'ltr'

  const cards = [
    {
      accent: MURRAM,
      accentLight: 'rgba(176, 73, 43, 0.15)',
      imageUrl: bikeCard.imageUrl,
      seed: bikeCard.tourId ?? 'bike',
      badge: isAr ? 'جولات الدراجات' : 'GROUP BIKE TOURS',
      heading: isAr ? 'مغامرة الدراجات' : 'MOTORBIKE ADVENTURE',
      body: isAr
        ? 'جولات دراجات جماعية بقيادة خبراء من نيروبي إلى الساحل. مدعومة بالكامل، ممتازة للمغامرين.'
        : 'Expert-led group rides from Nairobi to the coast. Fully supported, KTM-grade adventure for serious riders.',
      cta: isAr ? 'استكشف جولات الدراجات' : 'Explore Bike Tours',
      href: `/tours?lang=${locale}`,
    },
    {
      accent: GOLD,
      accentLight: 'rgba(201, 162, 75, 0.15)',
      imageUrl: privateCard.imageUrl,
      seed: privateCard.tourId ?? 'private',
      badge: isAr ? 'سفاري خاص' : 'PRIVATE SAFARI',
      heading: isAr ? 'سفاري بالسيارة' : 'CAR SAFARI',
      body: isAr
        ? 'مسارات مخصصة، مخيمات حصرية، مجموعتك وحدها فقط. سفاري مصمم حول تفضيلاتك.'
        : 'Custom itineraries, exclusive camps, your group only. Safari built entirely around your preferences.',
      cta: isAr ? 'استكشف السفاري الخاص' : 'Explore Private Safaris',
      href: `/tours?lang=${locale}`,
    },
  ]

  return (
    <section
      id="choose-trail"
      style={{
        background: BUSH,
        padding: 'var(--section-py) var(--container-px)',
      }}
      dir={dir}
    >
      <div style={{ maxWidth: 'var(--content-max)', margin: '0 auto' }}>

        {/* Heading */}
        <motion.div
          initial={reduced ? false : { opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, ease: EASE }}
          style={{ textAlign: 'center', marginBottom: 48 }}
        >
          <span className="text-caption" style={{ color: GOLD, display: 'block', marginBottom: 12 }}>
            {isAr ? 'مسارين مختلفين. نفس الشغف.' : 'Two Paths, One Passion'}
          </span>
          <h2 className="text-display-l" style={{ color: '#FFFFFF', margin: '0 0 16px' }}>
            {isAr ? 'اختر مسارك' : 'Choose Your Trail'}
          </h2>
          <p className="text-body" style={{ color: 'rgba(234, 227, 210, 0.7)', margin: 0, maxWidth: 480, marginInline: 'auto' }}>
            {isAr
              ? 'Whether you ride or prefer to be driven, your African adventure awaits.'
              : 'Whether you ride or prefer to be driven, your African adventure awaits.'}
          </p>
        </motion.div>

        {/* Fork SVG */}
        <div ref={ref} style={{ margin: '48px auto' }}>
          <ForkSVG inView={inView} reduced={reduced} isAr={isAr} />
        </div>

        {/* Cards */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
          gap: 'var(--card-gap)',
        }}>
          {cards.map((card, i) => (
            <motion.div
              key={card.badge}
              initial={reduced ? false : { opacity: 0, y: 32, x: isAr ? (i === 0 ? 24 : -24) : (i === 0 ? -24 : 24) }}
              animate={inView ? { opacity: 1, y: 0, x: 0 } : {}}
              transition={{ duration: 0.55, delay: i * 0.1 + 0.5, ease: EASE }}
              whileHover={reduced ? {} : { y: -6 }}
              style={{
                borderRadius: 'var(--radius-l)',
                overflow: 'hidden',
                position: 'relative',
                minHeight: 480,
                cursor: 'pointer',
                transition: 'var(--trans-std)',
              }}
            >
              <Link href={card.href} style={{ display: 'block', height: '100%', textDecoration: 'none' }}>
                {/* Image */}
                <div style={{ position: 'absolute', inset: 0, overflow: 'hidden' }}>
                  <SafariImage
                    src={card.imageUrl}
                    seed={card.seed}
                    alt={card.heading}
                    className="w-full h-full"
                    sizes="(max-width: 768px) 100vw, 50vw"
                  />
                  {/* Gradient overlay */}
                  <div style={{
                    position: 'absolute', inset: 0,
                    background: `linear-gradient(to top, ${card.accent}ee 0%, ${card.accent}77 45%, rgba(20, 25, 15, 0.4) 100%)`,
                  }} />
                </div>

                {/* Content */}
                <div style={{
                  position: 'relative', zIndex: 1,
                  display: 'flex', flexDirection: 'column', justifyContent: 'flex-end',
                  height: '100%', minHeight: 480,
                  padding: 'var(--card-pad)',
                }}>
                  {/* Badge */}
                  <div className="glass text-caption" style={{
                    borderRadius: 'var(--radius-xl)',
                    padding: '4px 14px',
                    color: '#FFFFFF',
                    marginBottom: 14,
                    alignSelf: 'flex-start',
                  }}>
                    {card.badge}
                  </div>

                  <h3 className="text-display-m" style={{ color: '#FFFFFF', margin: '0 0 12px' }}>
                    {card.heading}
                  </h3>

                  <p className="text-body-s" style={{ color: 'rgba(255, 255, 255, 0.88)', margin: '0 0 24px', maxWidth: 360 }}>
                    {card.body}
                  </p>

                  <div
                    className="text-button"
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: 8,
                      background: '#FFFFFF',
                      color: card.accent,
                      padding: '10px 22px',
                      borderRadius: 'var(--radius-s)',
                      alignSelf: 'flex-start',
                      transition: 'var(--trans-fast)',
                    }}
                  >
                    {card.cta}
                    {isAr ? <ArrowLeft size={16} /> : <ArrowRight size={16} />}
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
