'use client'

import Link from 'next/link'
import { Suspense } from 'react'
import { useLocale } from '@/lib/use-locale'
import { site, whatsappLink } from '@/lib/site'
import { Mail, Phone, Camera } from 'lucide-react'

const OLIVE = '#7A9A4A'
const BUSH = '#20271A'

export default function PublicFooter() {
  return (
    <Suspense fallback={null}>
      <FooterInner />
    </Suspense>
  )
}

function FooterInner() {
  const locale = useLocale()
  const isAr = locale === 'ar'
  const dir = isAr ? 'rtl' : 'ltr'
  const withLang = (href: string) => `${href}?lang=${locale}`

  const t = isAr ? {
    tagline: 'اختبر البرية. رحلات سفاري بقيادة خبراء عبر أكثر وجهات شرق أفريقيا شهرة.',
    explore: 'استكشف',
    browseTours: 'تصفح الجولات',
    gallery: 'معرض الصور',
    getQuote: 'احصل على عرض سعر',
    ourStory: 'قصتنا',
    company: 'الشركة',
    contactUs: 'اتصل بنا',
    privacy: 'سياسة الخصوصية',
    terms: 'شروط الخدمة',
    getInTouch: 'تواصل معنا',
    email: 'البريد الإلكتروني',
    phone: 'الهاتف',
    whatsapp: 'واتساب',
    rights: 'جميع الحقوق محفوظة.',
    crafted: 'صُنع في نيروبي',
  } : {
    tagline: "Experience the wild. Expert-led safaris across East Africa's most iconic destinations.",
    explore: 'Explore',
    browseTours: 'Browse Tours',
    gallery: 'Gallery',
    getQuote: 'Get a Quote',
    ourStory: 'Our Story',
    company: 'Company',
    contactUs: 'Contact Us',
    privacy: 'Privacy Policy',
    terms: 'Terms of Service',
    getInTouch: 'Get in Touch',
    email: 'Email',
    phone: 'Phone',
    whatsapp: 'WhatsApp',
    rights: 'All rights reserved.',
    crafted: 'Crafted in Nairobi',
  }

  return (
    <footer style={{ background: BUSH }} dir={dir}>
      <div style={{
        maxWidth: 'var(--content-max)',
        margin: '0 auto',
        padding: '64px var(--container-px) 32px',
      }}>
        {/* Main footer grid */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: 'var(--grid-gap)',
        }}>
          {/* Brand column */}
          <div>
            <div className="flex items-center gap-2.5 mb-4">
              <svg width="28" height="32" viewBox="0 0 28 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M14 2C8.5 2 4.5 6 4.5 10.5C4.5 13.5 6 16 8 17.5C6.5 18.5 5 20 5 22.5C5 26.5 9 30 14 30C19 30 23 26.5 23 22.5C23 20 21.5 18.5 20 17.5C22 16 23.5 13.5 23.5 10.5C23.5 6 19.5 2 14 2Z"
                  fill={OLIVE}
                />
                <circle cx="11" cy="12" r="1.5" fill={BUSH} />
                <circle cx="17" cy="12" r="1.5" fill={BUSH} />
                <path d="M12 16C12 16 13 17.5 14 17.5C15 17.5 16 16 16 16" stroke={BUSH} strokeWidth="1" strokeLinecap="round" />
              </svg>
              <span style={{
                fontFamily: 'var(--font-display)',
                fontWeight: 600,
                fontSize: '1.125rem',
                color: '#FFFFFF',
              }}>
                Safari Adventure Riders
              </span>
            </div>
            <p className="text-body-s" style={{ color: 'rgba(255, 255, 255, 0.5)', margin: '0 0 20px', maxWidth: 280 }}>
              {t.tagline}
            </p>
            <div className="flex items-center gap-4">
              <a
                href="https://instagram.com/safariadventureriders"
                target="_blank"
                rel="noopener noreferrer"
                className="transition-colors duration-200"
                style={{ color: 'rgba(255, 255, 255, 0.5)' }}
                onMouseEnter={(e) => { e.currentTarget.style.color = '#FFFFFF' }}
                onMouseLeave={(e) => { e.currentTarget.style.color = 'rgba(255, 255, 255, 0.5)' }}
              >
                <Camera size={20} />
              </a>
              <a
                href={whatsappLink()}
                target="_blank"
                rel="noopener noreferrer"
                className="transition-colors duration-200"
                style={{ color: 'rgba(255, 255, 255, 0.5)' }}
                onMouseEnter={(e) => { e.currentTarget.style.color = '#FFFFFF' }}
                onMouseLeave={(e) => { e.currentTarget.style.color = 'rgba(255, 255, 255, 0.5)' }}
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
              </a>
            </div>
          </div>

          {/* Explore column */}
          <div>
            <h3 className="text-caption" style={{ color: '#FFFFFF', marginBottom: 16 }}>
              {t.explore}
            </h3>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
              {[
                { label: t.browseTours, href: '/tours' },
                { label: t.gallery, href: '/gallery' },
                { label: t.getQuote, href: '/quote-request' },
                { label: t.ourStory, href: '/about' },
              ].map((link) => (
                <li key={link.href} style={{ marginBottom: 10 }}>
                  <Link
                    href={withLang(link.href)}
                    className="text-body-s link-underline"
                    style={{ color: 'rgba(255, 255, 255, 0.5)', textDecoration: 'none', transition: 'var(--trans-fast)' }}
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company column */}
          <div>
            <h3 className="text-caption" style={{ color: '#FFFFFF', marginBottom: 16 }}>
              {t.company}
            </h3>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
              {[
                { label: t.contactUs, href: '/contact' },
                { label: t.privacy, href: '/privacy' },
                { label: t.terms, href: '#' },
              ].map((link) => (
                <li key={link.label} style={{ marginBottom: 10 }}>
                  <Link
                    href={withLang(link.href)}
                    className="text-body-s link-underline"
                    style={{ color: 'rgba(255, 255, 255, 0.5)', textDecoration: 'none', transition: 'var(--trans-fast)' }}
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact column */}
          <div>
            <h3 className="text-caption" style={{ color: '#FFFFFF', marginBottom: 16 }}>
              {t.getInTouch}
            </h3>
            <div className="space-y-3">
              <a
                href={`mailto:${site.email}`}
                className="text-body-s flex items-center gap-2 transition-colors duration-200"
                style={{ color: 'rgba(255, 255, 255, 0.5)', textDecoration: 'none' }}
              >
                <Mail size={14} />
                {site.email}
              </a>
              <a
                href={`tel:${site.phoneE164}`}
                className="text-body-s flex items-center gap-2 transition-colors duration-200"
                style={{ color: 'rgba(255, 255, 255, 0.5)', textDecoration: 'none' }}
              >
                <Phone size={14} />
                {site.phoneDisplay}
              </a>
              <a
                href={whatsappLink()}
                className="text-body-s flex items-center gap-2 transition-colors duration-200"
                target="_blank"
                rel="noopener noreferrer"
                style={{ color: 'rgba(255, 255, 255, 0.5)', textDecoration: 'none' }}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
                {t.whatsapp}
              </a>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div style={{
          borderTop: '1px solid rgba(255, 255, 255, 0.15)',
          marginTop: 48,
          paddingTop: 24,
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: 8,
        }}>
          <p className="text-caption" style={{ color: 'rgba(255, 255, 255, 0.5)', margin: 0 }}>
            © {new Date().getFullYear()} {site.name}. {t.rights}
          </p>
          <p className="text-caption" style={{ color: 'rgba(255, 255, 255, 0.5)', margin: 0 }}>
            {t.crafted}
          </p>
        </div>
      </div>
    </footer>
  )
}
