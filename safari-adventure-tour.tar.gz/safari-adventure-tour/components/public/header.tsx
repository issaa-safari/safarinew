'use client'

import Link from 'next/link'
import Image from 'next/image'
import { useState, useEffect } from 'react'
import { useSearchParams, usePathname, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Menu, X } from 'lucide-react'

const OLIVE = '#7A9A4A'
const OLIVE_DK = '#3D5229'
const BUSH = '#20271A'
const STONE = '#6E6A59'
const SAND = '#EAE3D2'

export default function PublicHeader() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [mounted, setMounted] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const searchParams = useSearchParams()
  const pathname = usePathname()
  const router = useRouter()
  const [currentLang, setCurrentLang] = useState('en')
  const [signedIn, setSignedIn] = useState(false)

  // Track scroll position for header styling
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 80)
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    handleScroll()
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  // Track auth state
  useEffect(() => {
    const supabase = createClient()
    supabase.auth.getUser().then(({ data }) => setSignedIn(!!data.user))
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      setSignedIn(!!session?.user)
    })
    return () => sub.subscription.unsubscribe()
  }, [])

  async function handleSignOut() {
    const supabase = createClient()
    await supabase.auth.signOut()
    setSignedIn(false)
    router.push(`/?lang=${currentLang}`)
    router.refresh()
  }

  useEffect(() => {
    setMounted(true)
    const urlLang = searchParams.get('lang')
    if (urlLang === 'ar' || urlLang === 'en') {
      setCurrentLang(urlLang)
      return
    }
    const cookieLang = document.cookie
      .split('; ')
      .find((c) => c.startsWith('locale='))
      ?.split('=')[1]
    if (cookieLang === 'ar' || cookieLang === 'en') {
      setCurrentLang(cookieLang)
      return
    }
    let detected: 'en' | 'ar' = navigator.language.split('-')[0] === 'ar' ? 'ar' : 'en'
    try {
      const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''
      if (tz.includes('Mecca') || tz.includes('Riyadh') || tz.includes('Jeddah')) detected = 'ar'
    } catch {
      // ignore
    }
    setCurrentLang(detected)
  }, [searchParams])

  useEffect(() => {
    if (mounted) {
      document.cookie = `locale=${currentLang};path=/;max-age=31536000;samesite=lax`
    }
  }, [currentLang, mounted])

  const getLangUrl = (lang: 'en' | 'ar') => {
    const params = new URLSearchParams(searchParams.toString())
    params.set('lang', lang)
    return `${pathname}?${params.toString()}`
  }

  const getNavLink = (href: string) => {
    const params = new URLSearchParams(searchParams.toString())
    const lang = params.get('lang') || 'en'
    return `${href}?lang=${lang}`
  }

  const isAr = currentLang === 'ar'

  const navItems = [
    { href: '/tours', labelEn: 'Tours', labelAr: 'الجولات' },
    { href: '/departures', labelEn: 'Departures', labelAr: 'الرحلات' },
    { href: '/gallery', labelEn: 'Gallery', labelAr: 'المعرض' },
    { href: '/about', labelEn: 'About', labelAr: 'نبذة عنا' },
    { href: '/contact', labelEn: 'Contact', labelAr: 'اتصل بنا' },
  ]

  if (!mounted) return null

  return (
    <>
      <header
        className="fixed top-0 left-0 right-0 z-50 transition-all duration-350"
        style={{
          transitionTimingFunction: 'var(--ease)',
          backgroundColor: scrolled ? '#FFFFFF' : 'transparent',
          borderBottom: scrolled ? '1px solid rgba(32, 39, 26, 0.1)' : '1px solid transparent',
          boxShadow: scrolled ? 'var(--shadow-s)' : 'none',
        }}
      >
        <div
          className="flex items-center justify-between mx-auto"
          style={{
            maxWidth: 'var(--content-max)',
            padding: '0 var(--container-px)',
            height: 72,
          }}
        >
          {/* Logo */}
          <Link href={`/?lang=${currentLang}`} className="flex items-center gap-2.5">
            <svg width="28" height="32" viewBox="0 0 28 32" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M14 2C8.5 2 4.5 6 4.5 10.5C4.5 13.5 6 16 8 17.5C6.5 18.5 5 20 5 22.5C5 26.5 9 30 14 30C19 30 23 26.5 23 22.5C23 20 21.5 18.5 20 17.5C22 16 23.5 13.5 23.5 10.5C23.5 6 19.5 2 14 2Z"
                fill={scrolled ? OLIVE : '#FFFFFF'}
                fillOpacity="0.9"
              />
              <circle cx="11" cy="12" r="1.5" fill={scrolled ? BUSH : '#20271A'} />
              <circle cx="17" cy="12" r="1.5" fill={scrolled ? BUSH : '#20271A'} />
              <path
                d="M12 16C12 16 13 17.5 14 17.5C15 17.5 16 16 16 16"
                stroke={scrolled ? BUSH : '#20271A'}
                strokeWidth="1"
                strokeLinecap="round"
              />
              <path
                d="M8 9C8 9 6 8 5 6"
                stroke={scrolled ? BUSH : '#20271A'}
                strokeWidth="1.5"
                strokeLinecap="round"
              />
              <path
                d="M20 9C20 9 22 8 23 6"
                stroke={scrolled ? BUSH : '#20271A'}
                strokeWidth="1.5"
                strokeLinecap="round"
              />
            </svg>
            <span
              className="font-semibold text-lg"
              style={{
                fontFamily: 'var(--font-display)',
                color: scrolled ? BUSH : '#FFFFFF',
                transition: 'var(--trans-std)',
              }}
            >
              Safari Adventure Riders
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center" style={{ gap: 32 }}>
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={getNavLink(item.href)}
                className="link-underline text-nav"
                style={{
                  color: scrolled ? STONE : 'rgba(255,255,255,0.85)',
                  transition: 'var(--trans-fast)',
                }}
              >
                {isAr ? item.labelAr : item.labelEn}
              </Link>
            ))}

            {signedIn ? (
              <>
                <Link
                  href={getNavLink('/dashboard')}
                  className="link-underline text-nav"
                  style={{
                    color: scrolled ? STONE : 'rgba(255,255,255,0.85)',
                    transition: 'var(--trans-fast)',
                  }}
                >
                  {isAr ? 'حسابي' : 'Dashboard'}
                </Link>
                <button
                  onClick={handleSignOut}
                  className="text-nav"
                  style={{
                    color: scrolled ? STONE : 'rgba(255,255,255,0.85)',
                    transition: 'var(--trans-fast)',
                  }}
                >
                  {isAr ? 'تسجيل الخروج' : 'Sign Out'}
                </button>
              </>
            ) : (
              <Link
                href={getNavLink('/login')}
                className="link-underline text-nav"
                style={{
                  color: scrolled ? STONE : 'rgba(255,255,255,0.85)',
                  transition: 'var(--trans-fast)',
                }}
              >
                {isAr ? 'تسجيل الدخول' : 'Sign In'}
              </Link>
            )}

            <Link
              href={getNavLink('/quote-request')}
              className="text-button transition-all duration-350"
              style={{
                backgroundColor: OLIVE,
                color: '#FFFFFF',
                padding: '12px 24px',
                borderRadius: 'var(--radius-s)',
                transitionTimingFunction: 'var(--ease)',
                textDecoration: 'none',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = OLIVE_DK
                e.currentTarget.style.boxShadow = 'var(--shadow-m)'
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = OLIVE
                e.currentTarget.style.boxShadow = 'none'
              }}
            >
              {isAr ? 'طلب عرض سعر' : 'Request Quote'}
            </Link>

            {/* Language Toggle */}
            <div
              className="flex items-center"
              style={{
                gap: 4,
                marginLeft: 16,
                paddingLeft: 16,
                borderLeft: `1px solid ${scrolled ? 'rgba(32,39,26,0.1)' : 'rgba(255,255,255,0.2)'}`,
                transition: 'var(--trans-std)',
              }}
            >
              <Link
                href={getLangUrl('en')}
                className="text-caption transition-all duration-200"
                style={{
                  padding: '4px 12px',
                  borderRadius: 'var(--radius-xl)',
                  backgroundColor: currentLang === 'en' ? (scrolled ? BUSH : 'rgba(255,255,255,0.9)') : 'transparent',
                  color: currentLang === 'en' ? (scrolled ? '#FFFFFF' : BUSH) : (scrolled ? STONE : 'rgba(255,255,255,0.6)'),
                  textDecoration: 'none',
                  transitionTimingFunction: 'var(--ease)',
                }}
              >
                EN
              </Link>
              <Link
                href={getLangUrl('ar')}
                className="text-caption transition-all duration-200"
                style={{
                  padding: '4px 12px',
                  borderRadius: 'var(--radius-xl)',
                  backgroundColor: currentLang === 'ar' ? (scrolled ? BUSH : 'rgba(255,255,255,0.9)') : 'transparent',
                  color: currentLang === 'ar' ? (scrolled ? '#FFFFFF' : BUSH) : (scrolled ? STONE : 'rgba(255,255,255,0.6)'),
                  textDecoration: 'none',
                  transitionTimingFunction: 'var(--ease)',
                }}
              >
                العربية
              </Link>
            </div>
          </nav>

          {/* Mobile menu button */}
          <button
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            style={{ color: scrolled ? BUSH : '#FFFFFF' }}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </header>

      {/* Mobile menu overlay */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 z-40 flex flex-col items-center justify-center"
          style={{ backgroundColor: BUSH }}
        >
          <button
            className="absolute top-5 right-5 p-2"
            onClick={() => setMobileMenuOpen(false)}
            style={{ color: '#FFFFFF' }}
          >
            <X size={28} />
          </button>
          <nav className="flex flex-col items-center" style={{ gap: 24 }}>
            {navItems.map((item, i) => (
              <Link
                key={item.href}
                href={getNavLink(item.href)}
                className="text-display-m"
                style={{
                  color: '#FFFFFF',
                  textDecoration: 'none',
                  opacity: 0,
                  animation: `fadeInUp 0.4s ${i * 0.05}s forwards`,
                }}
                onClick={() => setMobileMenuOpen(false)}
              >
                {isAr ? item.labelAr : item.labelEn}
              </Link>
            ))}
            {signedIn ? (
              <>
                <Link
                  href={getNavLink('/dashboard')}
                  className="text-display-m"
                  style={{ color: '#FFFFFF', textDecoration: 'none' }}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {isAr ? 'حسابي' : 'Dashboard'}
                </Link>
                <button
                  onClick={() => {
                    handleSignOut()
                    setMobileMenuOpen(false)
                  }}
                  className="text-display-m"
                  style={{ color: 'rgba(255,255,255,0.7)', background: 'none', border: 'none' }}
                >
                  {isAr ? 'تسجيل الخروج' : 'Sign Out'}
                </button>
              </>
            ) : (
              <Link
                href={getNavLink('/login')}
                className="text-display-m"
                style={{ color: '#FFFFFF', textDecoration: 'none' }}
                onClick={() => setMobileMenuOpen(false)}
              >
                {isAr ? 'تسجيل الدخول' : 'Sign In'}
              </Link>
            )}
            <Link
              href={getNavLink('/quote-request')}
              className="text-button"
              style={{
                backgroundColor: OLIVE,
                color: '#FFFFFF',
                padding: '14px 32px',
                borderRadius: 'var(--radius-s)',
                textDecoration: 'none',
                marginTop: 16,
              }}
              onClick={() => setMobileMenuOpen(false)}
            >
              {isAr ? 'طلب عرض سعر' : 'Request Quote'}
            </Link>

            {/* Language Toggle Mobile */}
            <div className="flex gap-3 pt-6" style={{ borderTop: '1px solid rgba(255,255,255,0.15)' }}>
              <Link
                href={getLangUrl('en')}
                className="text-caption"
                style={{
                  padding: '6px 16px',
                  borderRadius: 'var(--radius-xl)',
                  backgroundColor: currentLang === 'en' ? 'rgba(255,255,255,0.15)' : 'transparent',
                  color: '#FFFFFF',
                  textDecoration: 'none',
                }}
                onClick={() => setMobileMenuOpen(false)}
              >
                EN
              </Link>
              <Link
                href={getLangUrl('ar')}
                className="text-caption"
                style={{
                  padding: '6px 16px',
                  borderRadius: 'var(--radius-xl)',
                  backgroundColor: currentLang === 'ar' ? 'rgba(255,255,255,0.15)' : 'transparent',
                  color: '#FFFFFF',
                  textDecoration: 'none',
                }}
                onClick={() => setMobileMenuOpen(false)}
              >
                العربية
              </Link>
            </div>
          </nav>
        </div>
      )}

      <style jsx>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </>
  )
}
