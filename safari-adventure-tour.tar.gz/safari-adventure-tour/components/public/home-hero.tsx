'use client'

import { motion, useReducedMotion } from 'framer-motion'
import Link from 'next/link'
import SafariImage from '@/components/public/safari-image'
import { ChevronDown } from 'lucide-react'

const BUSH = '#20271A'
const OLIVE = '#7A9A4A'
const EASE = [0.22, 1, 0.36, 1] as const

interface HomeHeroProps {
  heroImageUrl: string | null
  heroTourId: string | null
  isAr: boolean
  locale: string
}

export default function HomeHero({ heroImageUrl, heroTourId, isAr, locale }: HomeHeroProps) {
  const reduced = useReducedMotion()
  const dir = isAr ? 'rtl' : 'ltr'

  const t = isAr ? {
    eyebrow: 'تأسسنا ٢٠٠٩ · نيروبي، كينيا',
    headline: 'اختبر البرية',
    sub: 'جولات دراجات بقيادة خبراء وسفاري خاص عبر أشهر مناظر شرق أفريقيا. مصممة لمن يبحث عن أكثر من مجرد عطلة.',
    cta: 'خطط لمغامرتك',
    quote: 'طلب عرض سعر',
  } : {
    eyebrow: 'Est. 2009 · Nairobi, Kenya',
    headline: 'Experience the Wild',
    sub: "Expert-led motorbike tours and private safaris across East Africa's most iconic landscapes. Designed for those who seek more than a holiday.",
    cta: 'Plan Your Adventure',
    quote: 'Request a Quote',
  }

  return (
    <section
      dir={dir}
      style={{
        position: 'relative',
        minHeight: '100dvh',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'flex-end',
        overflow: 'hidden',
        background: BUSH,
      }}
    >
      {/* Background image with Ken Burns */}
      <motion.div
        initial={reduced ? false : { opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1.2, ease: EASE }}
        style={{ position: 'absolute', inset: 0 }}
      >
        <div className={reduced ? '' : 'animate-ken-burns'} style={{ width: '100%', height: '100%' }}>
          <SafariImage
            src={heroImageUrl}
            seed={heroTourId ?? 'home-hero'}
            alt="Safari Adventure Riders"
            className="w-full h-full"
            sizes="100vw"
            priority
          />
        </div>
        {/* Layered gradient overlay */}
        <div style={{
          position: 'absolute', inset: 0,
          background: 'linear-gradient(to top, rgba(32, 39, 26, 0.95) 0%, rgba(32, 39, 26, 0.6) 40%, rgba(32, 39, 26, 0.15) 70%, transparent 100%)',
        }} />
        {/* Subtle vignette */}
        <div style={{
          position: 'absolute', inset: 0,
          background: 'radial-gradient(ellipse at center, transparent 40%, rgba(32, 39, 26, 0.3) 100%)',
        }} />
      </motion.div>

      {/* Content */}
      <div style={{
        position: 'relative', zIndex: 1,
        maxWidth: 720,
        margin: isAr ? '0 auto 0 0' : '0 0 0 auto',
        width: '100%',
        padding: `0 var(--container-px) clamp(60px, 10vh, 100px)`,
      }}>
        {/* Eyebrow */}
        <motion.span
          initial={reduced ? false : { opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3, ease: EASE }}
          className="text-caption"
          style={{
            color: '#C9A24B',
            display: 'block',
            marginBottom: 16,
          }}
        >
          {t.eyebrow}
        </motion.span>

        {/* Headline */}
        <motion.h1
          initial={reduced ? false : { opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.45, ease: EASE }}
          className="text-display-xl"
          style={{
            color: '#FFFFFF',
            margin: '0 0 20px',
          }}
        >
          {t.headline}
        </motion.h1>

        {/* Subheadline */}
        <motion.p
          initial={reduced ? false : { opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6, ease: EASE }}
          className="text-body-l"
          style={{
            color: 'rgba(255, 255, 255, 0.8)',
            margin: '0 0 40px',
            maxWidth: 520,
          }}
        >
          {t.sub}
        </motion.p>

        {/* CTA Group */}
        <motion.div
          initial={reduced ? false : { opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.75, ease: EASE }}
          style={{ display: 'flex', flexWrap: 'wrap', gap: 14 }}
        >
          <a
            href="#choose-trail"
            className="text-button"
            style={{
              background: '#FFFFFF',
              color: BUSH,
              padding: '14px 32px',
              borderRadius: 'var(--radius-s)',
              textDecoration: 'none',
              display: 'inline-flex',
              alignItems: 'center',
              gap: 8,
              transition: 'var(--trans-fast)',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = '#EAE3D2'
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = '#FFFFFF'
            }}
          >
            {t.cta}
          </a>
          <Link
            href={`/quote-request?lang=${locale}`}
            className="text-button"
            style={{
              border: '1.5px solid rgba(255, 255, 255, 0.5)',
              color: '#FFFFFF',
              padding: '12px 28px',
              borderRadius: 'var(--radius-s)',
              textDecoration: 'none',
              display: 'inline-flex',
              alignItems: 'center',
              gap: 8,
              transition: 'var(--trans-fast)',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'rgba(255, 255, 255, 0.15)'
              e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.7)'
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'transparent'
              e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.5)'
            }}
          >
            {t.quote}
          </Link>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={reduced ? false : { opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 1.2, ease: EASE }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <ChevronDown
          size={24}
          className="animate-bounce-gentle"
          style={{ color: 'rgba(255, 255, 255, 0.5)' }}
        />
      </motion.div>
    </section>
  )
}
