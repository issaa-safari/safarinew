'use client'

import { motion, useReducedMotion } from 'framer-motion'
import type { ReactNode } from 'react'

const EASE = [0.22, 1, 0.36, 1] as const

interface SectionRevealProps {
  children: ReactNode
  delay?: number
  direction?: 'up' | 'left' | 'right'
  className?: string
}

export default function SectionReveal({
  children,
  delay = 0,
  direction = 'up',
  className,
}: SectionRevealProps) {
  const reduced = useReducedMotion()

  const getInitial = () => {
    switch (direction) {
      case 'left':
        return { opacity: 0, x: -40 }
      case 'right':
        return { opacity: 0, x: 40 }
      case 'up':
      default:
        return { opacity: 0, y: 30 }
    }
  }

  const getTarget = () => {
    switch (direction) {
      case 'left':
      case 'right':
        return { opacity: 1, x: 0 }
      case 'up':
      default:
        return { opacity: 1, y: 0 }
    }
  }

  return (
    <motion.div
      initial={getInitial()}
      whileInView={getTarget()}
      transition={{ duration: reduced ? 0 : 0.6, delay: reduced ? 0 : delay, ease: EASE }}
      viewport={{ once: true, margin: '-60px' }}
      className={className}
    >
      {children}
    </motion.div>
  )
}
